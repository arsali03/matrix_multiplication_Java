import java.util.Scanner;

public class determinant {
    public void deter() {
        Scanner keyword = new Scanner(System.in);
        System.out.println("Matrisinizin satır sayısı kaç olsun? ");
        int satir = keyword.nextInt();

        System.out.println("Matrisinizin sütun sayısı kaç olsun? ");
        int sutun = keyword.nextInt();

            int[][] matris1=new int[satir][sutun];

            int i;
        if (satir == 3 && sutun == 3) {
            System.out.println("1. Matrisin Determinantı :");


            for ( i=0; i < 3; i++)
            {
                for (int j=0; j < 3; j++)
                {
                    System.out.println("Lütfen 1. matris için ["+i+"]["+j+"] konumundaki elemani yazin");
                    matris1[i][j]=keyword.nextInt();
                }
            }
            int determinant = ((matris1[0][0] * matris1[1][1] * matris1[2][2] + matris1[0][1] * matris1[2][0] * matris1[1][2] + matris1[0][2] * matris1[1][0] * matris1[2][1]) - (matris1[0][0] * matris1[2][1] * matris1[1][2] + matris1[0][1] * matris1[1][0] * matris1[2][2] + matris1[0][2] * matris1[2][0] * matris1[1][1]));
            System.out.println("determinant: "+determinant+"\n");
        } else {
            System.out.print("Lütfen 1. matrisi 3 x 3 boyutunda giriniz !\n");

        }






    }}