import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner secim = new Scanner(System.in);
        matrisToplama toplama = new matrisToplama();
        matrisCikarma cikarma = new matrisCikarma();
        matrisCarpma carpma = new matrisCarpma();
        sbtMatrisCarpma sbtCarpma = new sbtMatrisCarpma();
        determinant determnd = new determinant();
        tersMatris tersMtrs = new tersMatris();
        involutifMatris involutif = new involutifMatris();




        System.out.println("\n--------Matris Hesaplama-------\n");

        System.out.println("Yapmak istediğiniz işlemi seçiniz:\n1.Matris Toplama\n2.Matris Çıkarma\n3.Matris Çarpma\n4.Sabit sayı ile Matris Çarpma\n5.(3x3) Matris Determinantı Hesaplama\n6.Matris Tersi Alma\n7.Matris İnvolutiflik Sorgusu\n");
        int deger = secim.nextInt();


            switch (deger){
                case 1:

                    toplama.top();
                    break;


                case 2:
                    cikarma.cik();
                    break;


                case 3:
                    carpma.carp();
                    break;


                case 4:
                    sbtCarpma.sbtCarp();
                    break;


                case 5:
                    determnd.deter();
                    break;


                case 6:
                    tersMtrs.ters();
                    break;



                case 7:
                    involutif.inv();
                    break;

                default:
                    System.out.println("Yanlış Giriş Yaptınız !!!");


            }





            System.out.println("Hesaplayıcıdan Çıkılıyor.....");

    }
}