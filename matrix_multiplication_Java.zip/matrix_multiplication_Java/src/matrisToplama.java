import java.lang.reflect.Array;
import java.util.Scanner;

public class matrisToplama {

    public  void top(){
        Scanner keyword = new Scanner(System.in);
        System.out.println("Matrisinizin satır sayısı kaç olsun? ");
        int satir = keyword.nextInt();

        System.out.println("Matrisinizin sütun sayısı kaç olsun? ");
        int sutun = keyword.nextInt();
        if(sutun==satir){
            int[][] matris1=new int[satir][sutun];
            int[][] matris2=new int[satir][sutun];
            int[][] matrisToplam=new int[satir][sutun];
            int i;
            for ( i=0; i < satir; i++)
            {
                for (int j=0; j < sutun; j++)
                {
                    System.out.println("Lütfen 1. matris için ["+i+"]["+j+"] konumundaki elemani yazin");
                    matris1[i][j]=keyword.nextInt();

                    System.out.println("Lütfen 2. matris için ["+i+"]["+j+"] konumundaki elemani yazin");
                    matris2[i][j]=keyword.nextInt();

                    matrisToplam[i][j]=matris1[i][j]+matris2[i][j];
                }


            }



            System.out.println("matris1 ve matris2'nin toplama sonucu:");

            for ( i = 0; i < satir; i++) {
                for (int j = 0; j < sutun; j++) {
                    System.out.print(matrisToplam[i][j] + "\t");
                }
                System.out.println();
            }

        }
        else{
            System.out.println("Bu matrisler toplanamaz!!");

        }







    }
}
