import java.util.Scanner;

public class matrisCikarma {
    public void cik(){
        Scanner keyword = new Scanner(System.in);
        System.out.println("Matrisinizin satır sayısı kaç olsun? ");
        int satir = keyword.nextInt();

        System.out.println("Matrisinizin sütun sayısı kaç olsun? ");
        int sutun = keyword.nextInt();

        if(satir==sutun){
            int[][] matris1=new int[satir][sutun];
            int[][] matris2=new int[satir][sutun];
            int[][] matrisCıkarma=new int[satir][sutun];
            int i;
            for ( i=0; i < satir; i++)
            {
                for (int j=0; j < sutun; j++)
                {
                    System.out.println("Lütfen 1. matris için ["+i+"]["+j+"] konumundaki elemani yazin");
                    matris1[i][j]=keyword.nextInt();

                    System.out.println("Lütfen 2. matris için ["+i+"]["+j+"] konumundaki elemani yazin");
                    matris2[i][j]=keyword.nextInt();

                    matrisCıkarma[i][j]=matris1[i][j]-matris2[i][j];
                }

            }
            System.out.println("matris1 ve matris2'nin cıkarma sonucu:");

            for ( i = 0; i < satir; i++) {
                for (int j = 0; j < sutun; j++) {
                    System.out.print(matrisCıkarma[i][j] + "\t");
                }
                System.out.println();
            }

        }
        else{
            System.out.println("Bu matrisler cıkarılamaz!!");
        }


    }
}
