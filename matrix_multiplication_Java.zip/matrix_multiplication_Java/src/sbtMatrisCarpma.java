import java.util.Scanner;

public class sbtMatrisCarpma {
    public void sbtCarp(){

        Scanner keyword = new Scanner(System.in);
        System.out.println("Matrisinizin satır sayısı kaç olsun? ");
        int satir = keyword.nextInt();

        System.out.println("Matrisinizin sütun sayısı kaç olsun? ");
        int sutun = keyword.nextInt();

        System.out.println("Matrisinizi hangi sayıyla çarpmak istersiniz? ");
        int sbt = keyword.nextInt();

        int[][] matris1=new int[satir][sutun];
        int[][] sbtCarpma=new int[satir][sutun];



        int i;
        for ( i=0; i < satir; i++)
        {
            for (int j=0; j < sutun; j++)
            {
                System.out.println("Lütfen 1. matris için ["+i+"]["+j+"] konumundaki elemani yazin");
                matris1[i][j]=keyword.nextInt();

                sbtCarpma[i][j]=matris1[i][j]*sbt;
            }

        }
        System.out.println("matris1 ve sabit sayının carpma sonucu:");

        for ( i = 0; i < satir; i++) {
            for (int j = 0; j < sutun; j++) {
                System.out.print(sbtCarpma[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
