import java.util.Scanner;

public class matrisCarpma {
    public void carp(){

        Scanner keyword = new Scanner(System.in);
        System.out.println("Matrisinizin satır sayısı kaç olsun? ");
        int satir = keyword.nextInt();

        System.out.println("Matrisinizin sütun sayısı kaç olsun? ");
        int sutun = keyword.nextInt();

        int[][] matris1=new int[satir][sutun];
        int[][] matris2=new int[satir][sutun];
        int[][] matrisA=new int[satir][sutun];
        int[][] matrisB=new int[satir][sutun];
        int i,n;
        int sonuc=0;

        for ( i=0; i < satir; i++)
        {
            for (int j=0; j < sutun; j++)
            {
                System.out.println("Lütfen 1. matris için ["+i+"]["+j+"] konumundaki elemani yazin");
                matris1[i][j]=keyword.nextInt();

                System.out.println("Lütfen 2. matris için ["+i+"]["+j+"] konumundaki elemani yazin");
                matris2[i][j]=keyword.nextInt();


            }


        }
        for ( i=0; i < satir; i++)
        {
            for (int j=0; j < sutun; j++)
            {


                for(n=0;n<satir;n++){
                   sonuc= sonuc +( matris1[i][n]*matris2[n][j]);

                }
                matrisB[i][j]=sonuc;
                sonuc=0;

            }


        }

        System.out.println("matris1 ve matris2'nin carpma sonucu:");

        for ( i = 0; i < satir; i++) {
            for (int j = 0; j < sutun; j++) {
                System.out.print(matrisB[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
