import java.util.Scanner;

public class involutifMatris {
    public void inv(){
        int i,j;



        Scanner keyword = new Scanner(System.in);
        System.out.println("Matrisinizin satır sayısı kaç olsun? ");
        int satir = keyword.nextInt();

        System.out.println("Matrisinizin sütun sayısı kaç olsun? ");
        int sutun = keyword.nextInt();

        int[][] matris1=new int[satir][sutun];
        int[][] matrisInvolutif=new int[satir][sutun];

        for ( i=0; i < satir; i++)
        {
            for ( j=0; j < sutun; j++)
            {
                System.out.println("Lütfen 1. matris için ["+i+"]["+j+"] konumundaki elemani yazin");
                matris1[i][j]=keyword.nextInt();




            }


        }

        if(satir==sutun){
            for (i = 0; i < satir; i++) {
                for (j = 0; j < sutun; j++) {
                    matrisInvolutif[i][j] = 0;
                }
            }
            for (i = 0; i < satir; i++) {
                for (j = 0; j < sutun; j++) {
                    for (int c = 0; c < satir; c++) {
                        matrisInvolutif[i][j] += matris1[i][c] * matris1[c][j];
                    }
                }
            }
            System.out.println("1. Matrisin Karesi :");
            for (i = 0; i < satir; i++) {
                for (j = 0; j < sutun; j++) {
                    System.out.print(matrisInvolutif[i][j] + "\t");
                }
                System.out.println();
            }
            int flag=0;
            for (i = 0; i < satir; i++) {
                for (j = 0; j < sutun; j++) {
                    boolean falseCondition = (i == j && matrisInvolutif[i][j] != 1);
                    boolean falseCondition2 = (i != j && matrisInvolutif[i][j] != 0);
                    if ((falseCondition) || (falseCondition2)) {
                        flag=1;
                        break;
                    }
                }

            }
            if(flag==1){
                System.out.println("İnvolutif matris değildir");
            }
            else{
                System.out.println("İnvolutif matristir");
            }
        }else{
            System.out.println("Lütfen kare matris giriniz !");

        }

    }
}
